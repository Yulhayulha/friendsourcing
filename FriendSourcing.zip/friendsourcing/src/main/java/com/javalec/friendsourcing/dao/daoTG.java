package com.javalec.friendsourcing.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.javalec.friendsourcing.dto.FeedDto;
import com.javalec.friendsourcing.dto.FollowDto;

public interface daoTG {
	public void fileUpload(@Param("uploadpath") String uploadpath,@Param("uuid") String uuid,@Param("filename") String filename,@Param("memId") String memId);
	public void feedUpload(HashMap<String, String> param);
	public String feedNum();
	public String feedCount();
	public int feedFollow(HashMap<String, String> param);
	public String[] followListView(HashMap<String, String> param);
	public int followDelete(HashMap<String, String> param);
	
	//main ȭ�� ��ü �ǵ� ���
	public ArrayList<FeedDto> feedList(@Param("startRowNum") int startRowNum,@Param("endRowNum") int endRowNum);
	//�ȷο��� ģ�� or �� �ǵ� ���
	public ArrayList<FeedDto> followfeedList(HashMap<String, Object> param); 
	public ArrayList<FeedDto> myLikeFeedList(HashMap<String, Object> param);
	public ArrayList<FeedDto> myFeedList(HashMap<String, Object> param);
	public ArrayList<FeedDto> myTagFeedList(HashMap<String, Object> param);
	//�±׻���
	public void tagInsert(HashMap<String, String> param);
	public void hashtagInsert(HashMap<String, String> param);
}
