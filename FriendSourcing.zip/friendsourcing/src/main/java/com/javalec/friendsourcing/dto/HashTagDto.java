package com.javalec.friendsourcing.dto;

public class HashTagDto {
	private String hashtag;
	private int feed_fenum;
	
	public HashTagDto() {
		// TODO Auto-generated constructor stub
	}
	
	public String getHashtag() {
		return hashtag;
	}
	public void setHashtag(String hashtag) {
		this.hashtag = hashtag;
	}
	public int getFeed_fenum() {
		return feed_fenum;
	}
	public void setFeed_fenum(int feed_fenum) {
		this.feed_fenum = feed_fenum;
	}
	
	public HashTagDto(String hashtag, int feed_fenum) {
		this.hashtag = hashtag;
		this.feed_fenum = feed_fenum;
	}
	
	
	
}
